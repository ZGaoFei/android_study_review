### 第一部

    1、Android 新特性
    2、Material Design
    3、View体系与自定义View
    4、多线程编程
    5、网络编程与网络框架
    6、设计模式
    7、事件总线
    8、函数式编程
    9、注解与依赖注入框架
    10、应用架构设计
    11、系统架构与MediaPlayer框架

## 第二部

    1、Android 系统架构
    2、Android 系统启动
    3、应用程序进程启动过程
    4、四大组件的工作过程
    5、理解上下文Context
    6、理解ActivityManagerService
    7、理解WindowsManager
    8、理解WindowsManagerService
    9、JNI原理
    10、Java虚拟机
    11、Dalvik 和 ART
    12、理解 ClassLoader
    13、热修复原理
    14、Hook技术
    15、插件化原理
    16、绘制优化
    17、内存优化

    关注：
    1、系统启动
    2、应用启动
    3、Activity启动
    4、Context
    5、Java虚拟机
    6、ClassLoader
    7、热修复、Hook、插件化、组件化、MultiDex

## 第三部

    1、系统源码的下载、编译、调试
    2、理解包管理机制和PMS
    3、理解输入系统和IMS
    4、IPC机制
    5、Native Binder原理
    6、Java Binder原理
    7、Groovy 基础
    8、Gradle 核心思想
    9、Gradle 的Android插件
    10、Android Jetpack 框架组件
    11、跨平台技术演进
    12、Dart基础
    13、Flutter基础

    关注：
    1、IPC
    2、Jetpack
    3、跨平台

#### Hook

```
什么是 Hook
Hook 又叫“钩子”，它可以在事件传送的过程中截获并监控事件的传输，将自身的代码与系统方法进行融入。这样当这些方法被调用时，也就可以执行我们自己的代码，这也是面向切面编程的思想（AOP）。

Hook 分类
1.根据Android开发模式，Native模式（C/C++）和Java模式（Java）区分，在Android平台上
Java层级的Hook；
Native层级的Hook；

2.根 Hook 对象与 Hook 后处理事件方式不同，Hook还分为：
消息Hook；
API Hook；

3.针对Hook的不同进程上来说，还可以分为：
全局Hook；
单个进程Hook；

```

